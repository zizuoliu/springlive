package net.nvsoftware.KafkaProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
