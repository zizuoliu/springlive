package net.nvsoftware.RabbitMQDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitMqDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
